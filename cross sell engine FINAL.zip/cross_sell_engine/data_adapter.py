"""
data_adapter.py
----------------
Maps client-specific field names to the engine's internal schema.

Client data format (EXACT fields from your Excel):
    - UCIC → customer_id
    - DEPTRANS_POST_DATE → transaction_date  
    - DEPTRANS_AMOUNT → amount
    - DEPTRANS_TYPE_CODE → channel (POS→Card, ACH→ACH, CHECK→Check, BILL→Bill Pay)
    - DEPTRANS_MEMO → raw_description
    - MERCHANT or CLEANSED → cleansed_description
    - CATEGORY1 → category
    - DEPTRANS_CATEGORY_CODE → mcc_code
    - DEPTRANS_CATEGORY_DESC → mcc_description

Engine's expected format:
    - transaction_id, customer_id, transaction_date, amount, channel,
      raw_description, cleansed_description, mcc_code, mcc_description, category
"""

import pandas as pd
import numpy as np


# Channel mapping: DEPTRANS_TYPE_CODE → standardized channel
CHANNEL_MAPPING = {
    "POS": "Card",
    "ACH": "ACH",
    "CHECK": "Check",
    "BILL": "Bill Pay",
}


def load_and_transform(csv_path: str) -> pd.DataFrame:
    """
    Loads your CSV and transforms it to the engine's expected format.

    Args:
        csv_path: Path to your transaction CSV with UCIC, DEPTRANS_*, etc.

    Returns:
        DataFrame with engine-compatible schema.
    """
    # Load raw data
    df = pd.read_csv(csv_path)

    # Validate required columns
    required = ["UCIC", "DEPTRANS_POST_DATE", "DEPTRANS_AMOUNT", "CATEGORY1"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    # Transform to engine schema
    transformed = pd.DataFrame({
        "customer_id": df["UCIC"].astype(str),
        "transaction_date": pd.to_datetime(df["DEPTRANS_POST_DATE"], format="%m/%d/%Y", errors="coerce"),
        "amount": pd.to_numeric(df["DEPTRANS_AMOUNT"], errors="coerce"),
        "channel": df.get("DEPTRANS_TYPE_CODE", "POS").map(CHANNEL_MAPPING).fillna("Card"),
        "raw_description": df.get("DEPTRANS_MEMO", df.get("DEPTRANS_PAYEE", "UNKNOWN")).fillna("UNKNOWN"),
        "cleansed_description": df.get("CLEANSED", df.get("MERCHANT", "UNKNOWN")).fillna("UNKNOWN"),
        "category": df["CATEGORY1"],
        "mcc_code": pd.to_numeric(df.get("DEPTRANS_CATEGORY_CODE", 5999), errors="coerce").fillna(5999).astype(int),
        "mcc_description": df.get("DEPTRANS_CATEGORY_DESC", "Miscellaneous").fillna("Miscellaneous"),
    })

    # Add transaction_id if not present
    transformed.insert(0, "transaction_id", range(1, len(transformed) + 1))

    # Drop rows with invalid dates or amounts
    transformed = transformed.dropna(subset=["transaction_date", "amount"])
    transformed = transformed[transformed["amount"] > 0]

    return transformed


def transform_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Transforms an already-loaded DataFrame (e.g. from Streamlit file uploader).

    Args:
        df: Raw DataFrame with your field names.

    Returns:
        Transformed DataFrame with engine schema.
    """
    required = ["UCIC", "DEPTRANS_POST_DATE", "DEPTRANS_AMOUNT", "CATEGORY1"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    transformed = pd.DataFrame({
        "customer_id": df["UCIC"].astype(str),
        "transaction_date": pd.to_datetime(df["DEPTRANS_POST_DATE"], format="%m/%d/%Y", errors="coerce"),
        "amount": pd.to_numeric(df["DEPTRANS_AMOUNT"], errors="coerce"),
        "channel": df.get("DEPTRANS_TYPE_CODE", "POS").map(CHANNEL_MAPPING).fillna("Card"),
        "raw_description": df.get("DEPTRANS_MEMO", df.get("DEPTRANS_PAYEE", "UNKNOWN")).fillna("UNKNOWN"),
        "cleansed_description": df.get("CLEANSED", df.get("MERCHANT", "UNKNOWN")).fillna("UNKNOWN"),
        "category": df["CATEGORY1"],
        "mcc_code": pd.to_numeric(df.get("DEPTRANS_CATEGORY_CODE", 5999), errors="coerce").fillna(5999).astype(int),
        "mcc_description": df.get("DEPTRANS_CATEGORY_DESC", "Miscellaneous").fillna("Miscellaneous"),
    })

    transformed.insert(0, "transaction_id", range(1, len(transformed) + 1))
    transformed = transformed.dropna(subset=["transaction_date", "amount"])
    transformed = transformed[transformed["amount"] > 0]

    return transformed
