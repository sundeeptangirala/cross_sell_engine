"""
model.py
---------
Complete cross-sell detection engine in one file.

Detects external financial relationships (mortgages, auto loans, credit cards, etc.)
from transaction patterns.

Usage:
    from model import detect_cross_sell
    from data import load_data
    
    transactions = load_data(source='csv', csv_path='data.csv')
    detections = detect_cross_sell(transactions)
"""

import pandas as pd
import numpy as np
from datetime import datetime
from typing import List, Dict, Tuple
from dataclasses import dataclass
from data import CONFIG


# =============================================================================
# DATA MODELS
# =============================================================================

@dataclass
class RecurringPayment:
    """Detected recurring payment pattern"""
    customer_id: str
    merchant: str
    category: str
    mean_amount: float
    median_amount: float
    amount_cv: float
    occurrence_count: int
    tenure_months: float
    cadence_type: str  # monthly, biweekly, weekly, irregular
    cadence_strength: float
    dominant_channel: str
    first_date: datetime
    last_date: datetime
    transaction_ids: List[int]


@dataclass
class Detection:
    """Final product detection result"""
    customer_id: str
    detected_product_type: str
    confidence_tier: str
    confidence_score: float
    first_detected_date: str
    last_detected_date: str
    tenure_months: float
    recurring_amount_band: str
    mean_amount: float
    canonical_merchant: str
    dominant_channel: str
    evidence_transaction_refs: str
    explanation_reason_codes: str


# =============================================================================
# RECURRING PAYMENT DETECTOR
# =============================================================================

def detect_recurring_payments(transactions: pd.DataFrame, lookback_days: int = 365) -> List[RecurringPayment]:
    """
    Stage 1: Detect ALL recurring payment patterns (product-agnostic).
    
    Groups by (customer, merchant) and analyzes:
    - Payment cadence (monthly, biweekly, weekly, irregular)
    - Amount stability (CV, IQR)
    - Tenure
    - Channel consistency
    """
    cutoff_date = transactions['transaction_date'].max() - pd.Timedelta(days=lookback_days)
    df = transactions[transactions['transaction_date'] >= cutoff_date].copy()
    
    patterns = []
    
    for (customer, merchant), group in df.groupby(['customer_id', 'merchant']):
        if len(group) < 3:
            continue
        
        group = group.sort_values('transaction_date')
        amounts = group['amount'].values
        dates = group['transaction_date'].values
        
        # Amount statistics
        mean_amt = np.mean(amounts)
        median_amt = np.median(amounts)
        cv = np.std(amounts) / mean_amt if mean_amt > 0 else 999
        
        # Cadence analysis
        gaps = np.diff(dates).astype('timedelta64[D]').astype(int)
        if len(gaps) == 0:
            continue
        
        median_gap = np.median(gaps)
        gap_cv = np.std(gaps) / np.mean(gaps) if np.mean(gaps) > 0 else 999
        
        if 25 <= median_gap <= 35:
            cadence = 'monthly'
            strength = max(0, 1 - gap_cv)
        elif 12 <= median_gap <= 16:
            cadence = 'biweekly'
            strength = max(0, 1 - gap_cv)
        elif 5 <= median_gap <= 9:
            cadence = 'weekly'
            strength = max(0, 1 - gap_cv)
        else:
            cadence = 'irregular'
            strength = 0.3
        
        # Tenure
        tenure_months = (dates[-1] - dates[0]).astype('timedelta64[D]').astype(int) / 30.0
        
        # Channel
        channels = group['channel'].value_counts()
        dominant_channel = channels.index[0] if len(channels) > 0 else 'Unknown'
        
        # Category
        category = group['category'].iloc[0] if 'category' in group.columns else 'Unknown'
        
        patterns.append(RecurringPayment(
            customer_id=customer,
            merchant=merchant,
            category=category,
            mean_amount=mean_amt,
            median_amount=median_amt,
            amount_cv=cv,
            occurrence_count=len(group),
            tenure_months=tenure_months,
            cadence_type=cadence,
            cadence_strength=strength,
            dominant_channel=dominant_channel,
            first_date=dates[0],
            last_date=dates[-1],
            transaction_ids=group.index.tolist() if hasattr(group.index, 'tolist') else list(range(len(group)))
        ))
    
    return patterns


# =============================================================================
# PRODUCT INTERPRETERS
# =============================================================================

def interpret_product(pattern: RecurringPayment, product_type: str) -> Tuple[bool, float, List[str]]:
    """
    Stage 2: Apply product-specific rules to a recurring pattern.
    
    Returns:
        (passes_gates, confidence_score, reason_codes)
    """
    rules = CONFIG['products'].get(product_type)
    if not rules:
        return False, 0.0, []
    
    # Hard gates
    if pattern.mean_amount < rules['min_amount'] or pattern.mean_amount > rules['max_amount']:
        return False, 0.0, ['AMOUNT_OUT_OF_RANGE']
    
    if pattern.amount_cv > rules['max_cv']:
        return False, 0.0, ['AMOUNT_TOO_VARIABLE']
    
    if pattern.tenure_months < rules['min_tenure']:
        return False, 0.0, ['TENURE_TOO_SHORT']
    
    if pattern.cadence_type not in ['monthly', 'biweekly']:
        return False, 0.0, ['CADENCE_NOT_RECURRING']
    
    # Scoring
    score = 0.0
    reasons = []
    
    # Cadence score (30%)
    if pattern.cadence_type == 'monthly':
        score += 0.30 * pattern.cadence_strength
        reasons.append('CADENCE_MONTHLY')
    elif pattern.cadence_type == 'biweekly':
        score += 0.25 * pattern.cadence_strength
        reasons.append('CADENCE_BIWEEKLY')
    
    # Amount stability (30%)
    stability_score = max(0, 1 - (pattern.amount_cv / rules['max_cv']))
    score += 0.30 * stability_score
    if pattern.amount_cv < 0.05:
        reasons.append('AMOUNT_STABLE')
    elif pattern.amount_cv < 0.15:
        reasons.append('AMOUNT_VARIABLE')
    
    # Tenure (20%)
    tenure_score = min(1.0, pattern.tenure_months / 12.0)
    score += 0.20 * tenure_score
    reasons.append(f'TENURE_{int(pattern.tenure_months)}MO')
    
    # Channel (20%)
    if pattern.dominant_channel in rules['expected_channels']:
        score += 0.20
        reasons.append('CHANNEL_MATCH')
    
    # Taxonomy bonus
    if CONFIG['taxonomy'].get(pattern.category) == product_type:
        score += 0.05
        reasons.append('TAXONOMY_MATCH')
    
    return True, min(1.0, score), reasons


def assign_confidence_tier(score: float) -> str:
    """Map score to High/Medium/Low tier"""
    for tier, bounds in CONFIG['confidence_tiers'].items():
        if bounds['min'] <= score < bounds['max']:
            return tier
    return 'Low'


def get_amount_band(amount: float) -> str:
    """Categorize amounts into bands"""
    if amount < 100:
        return '$0-100'
    elif amount < 300:
        return '$100-300'
    elif amount < 600:
        return '$300-600'
    elif amount < 1000:
        return '$600-1K'
    elif amount < 2000:
        return '$1K-2K'
    elif amount < 3000:
        return '$2K-3K'
    else:
        return '$3K+'


# =============================================================================
# MAIN PIPELINE
# =============================================================================

def detect_cross_sell(
    transactions: pd.DataFrame,
    lookback_days: int = 365,
    min_confidence: str = 'Medium'
) -> pd.DataFrame:
    """
    Complete detection pipeline.
    
    Args:
        transactions: Standardized transaction DataFrame
        lookback_days: How far back to analyze
        min_confidence: Minimum tier to return ('High', 'Medium', 'Low')
    
    Returns:
        DataFrame with detections
    """
    print(f"\n{'='*70}")
    print("  CROSS-SELL DETECTION PIPELINE")
    print(f"{'='*70}")
    
    # Stage 1: Detect recurring patterns
    print(f"\nStage 1: Detecting recurring payment patterns...")
    patterns = detect_recurring_payments(transactions, lookback_days)
    print(f"✓ Found {len(patterns):,} recurring patterns")
    
    # Stage 2: Interpret each pattern against each product
    print(f"\nStage 2: Classifying patterns into product types...")
    detections = []
    
    products = list(CONFIG['products'].keys())
    
    for pattern in patterns:
        for product_type in products:
            passes, score, reasons = interpret_product(pattern, product_type)
            
            if passes:
                tier = assign_confidence_tier(score)
                
                detections.append(Detection(
                    customer_id=pattern.customer_id,
                    detected_product_type=product_type,
                    confidence_tier=tier,
                    confidence_score=score,
                    first_detected_date=pd.Timestamp(pattern.first_date).strftime('%Y-%m-%d'),
                    last_detected_date=pd.Timestamp(pattern.last_date).strftime('%Y-%m-%d'),
                    tenure_months=pattern.tenure_months,
                    recurring_amount_band=get_amount_band(pattern.mean_amount),
                    mean_amount=pattern.mean_amount,
                    canonical_merchant=pattern.merchant,
                    dominant_channel=pattern.dominant_channel,
                    evidence_transaction_refs='|'.join(map(str, pattern.transaction_ids)),
                    explanation_reason_codes=' | '.join(reasons)
                ))
    
    print(f"✓ Generated {len(detections):,} detections")
    
    # Convert to DataFrame
    if not detections:
        print("\n⚠ No detections produced")
        return pd.DataFrame()
    
    df = pd.DataFrame([vars(d) for d in detections])
    
    # Filter by confidence
    tier_order = {'High': 3, 'Medium': 2, 'Low': 1}
    min_value = tier_order.get(min_confidence, 2)
    df = df[df['confidence_tier'].map(tier_order) >= min_value].copy()
    
    print(f"\nAfter filtering (>= {min_confidence}): {len(df):,} detections")
    
    # Summary
    print(f"\nProduct breakdown:")
    for prod in df['detected_product_type'].unique():
        count = len(df[df['detected_product_type'] == prod])
        high = len(df[(df['detected_product_type'] == prod) & (df['confidence_tier'] == 'High')])
        print(f"  • {prod:30s} {count:>4,} ({high} High)")
    
    print(f"\n{'='*70}\n")
    
    return df
