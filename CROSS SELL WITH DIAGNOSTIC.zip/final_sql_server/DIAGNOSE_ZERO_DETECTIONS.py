"""
DIAGNOSE_ZERO_DETECTIONS.py
----------------------------
Run this to understand why patterns aren't becoming detections.

This will help tune the CONFIG thresholds to match your real data.
"""

import pandas as pd
import pyodbc
from datetime import datetime

print("="*70)
print("  DIAGNOSING: 2,721 PATTERNS → 0 DETECTIONS")
print("="*70)

# Connect to database
conn_str = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=VSDSESOLDEV03;"
    "DATABASE=SEGEDW;"
    "Trusted_Connection=yes;"
)

print("\nConnecting to SEGEDW...")
conn = pyodbc.connect(conn_str)

# Get sample of recurring patterns from your data
print("\nAnalyzing your actual data patterns...")

query = """
SELECT TOP 50
    UCIC as customer_id,
    CLEANSED as merchant,
    CATEGORY1 as category,
    COUNT(*) as txn_count,
    AVG(DEPTRANS_AMOUNT) as mean_amount,
    MIN(DEPTRANS_AMOUNT) as min_amount,
    MAX(DEPTRANS_AMOUNT) as max_amount,
    STDEV(DEPTRANS_AMOUNT) / AVG(DEPTRANS_AMOUNT) as amount_cv,
    MIN(DEPTRANS_POST_DATE) as first_date,
    MAX(DEPTRANS_POST_DATE) as last_date,
    DATEDIFF(month, MIN(DEPTRANS_POST_DATE), MAX(DEPTRANS_POST_DATE)) as tenure_months
FROM [SEG_E0].[SAT_SEG_DEP_TRAN]
WHERE CLEANSED IS NOT NULL
    AND DEPTRANS_POST_DATE > '2024-01-01'
    AND DEPTRANS_AMOUNT > 0
GROUP BY UCIC, CLEANSED, CATEGORY1
HAVING COUNT(*) >= 5
ORDER BY txn_count DESC
"""

df = pd.read_sql(query, conn)
conn.close()

print(f"\n✓ Found {len(df)} recurring patterns in your data")
print("\n" + "="*70)
print("PATTERN ANALYSIS")
print("="*70)

# Analyze categories
print("\n1. CATEGORY VALUES IN YOUR DATA:")
categories = df['category'].value_counts()
for cat, count in categories.head(10).items():
    print(f"   {cat}: {count} patterns")

# Analyze amounts
print("\n2. AMOUNT RANGES:")
print(f"   Min: ${df['mean_amount'].min():.2f}")
print(f"   Max: ${df['mean_amount'].max():.2f}")
print(f"   Median: ${df['mean_amount'].median():.2f}")

# Analyze CV
print("\n3. AMOUNT VARIABILITY (CV):")
print(f"   Min CV: {df['amount_cv'].min():.3f}")
print(f"   Max CV: {df['amount_cv'].max():.3f}")
print(f"   Median CV: {df['amount_cv'].median():.3f}")
print(f"   Patterns with CV > 0.30: {len(df[df['amount_cv'] > 0.30])} ({len(df[df['amount_cv'] > 0.30])/len(df)*100:.1f}%)")

# Analyze tenure
print("\n4. TENURE:")
print(f"   Min tenure: {df['tenure_months'].min():.1f} months")
print(f"   Max tenure: {df['tenure_months'].max():.1f} months")
print(f"   Median tenure: {df['tenure_months'].median():.1f} months")
print(f"   Patterns with tenure < 2 months: {len(df[df['tenure_months'] < 2])}")

# Sample patterns
print("\n5. TOP 10 ACTUAL PATTERNS:")
print(df[['merchant', 'category', 'txn_count', 'mean_amount', 'amount_cv', 'tenure_months']].head(10).to_string(index=False))

print("\n" + "="*70)
print("COMPARISON TO CONFIG THRESHOLDS")
print("="*70)

from data import CONFIG

print("\nYour CONFIG expects these categories in taxonomy:")
for cat in CONFIG['taxonomy'].keys():
    print(f"   - {cat}")

print(f"\nBut your data has categories like:")
for cat in categories.head(5).index:
    print(f"   - {cat}")

print("\n❌ MISMATCH! That's why 0 detections.")

print("\n" + "="*70)
print("SOLUTIONS")
print("="*70)

print("""
Option 1: UPDATE TAXONOMY in data.py
   Edit CONFIG['taxonomy'] to map YOUR categories to products:
   
   'taxonomy': {
       'CONVENIENCE STORES': 'Insurance',  # Example
       'GENERAL MERCHANDISE': 'External Credit Card',
       # Add mappings for your actual categories
   }

Option 2: RELAX THRESHOLDS in data.py
   Based on your data above, adjust:
   - min_amount / max_amount (if amounts are outside ranges)
   - max_cv (if your CV values are higher)
   - min_tenure (if your patterns are shorter-lived)

Option 3: IGNORE TAXONOMY and use amount-based detection
   Remove taxonomy dependency in model.py interpret_product()
   
RECOMMENDED: Start with Option 1 - map your categories properly.
""")

print("\n" + "="*70)
print("Next step: Share this output and I'll update the CONFIG for you")
print("="*70)
