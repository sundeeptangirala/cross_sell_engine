"""
data.py
--------
SQL Server connector for VSDSESOLDEV03

Source: SEGEDW.SEG_E0.SAT_SEG_DEP_TRAN
Target: DATASCIENCE.dbo.*

Uses Windows Authentication (your MYFNB\tangiralas credentials)
"""

import pandas as pd
import pyodbc
from datetime import datetime
from typing import Optional


# =============================================================================
# CONFIGURATION - YOUR EXACT SETUP
# =============================================================================

CONFIG = {
    # Your SQL Server (from screenshot)
    'server': 'VSDSESOLDEV03',
    'source_db': 'SEGEDW',
    'target_db': 'DATASCIENCE',
    
    # Source table (from your screenshot)
    'source_schema': 'SEG_E0',
    'source_table': 'SAT_SEG_DEP_TRAN',
    
    # Target tables (all in DATASCIENCE.dbo)
    'target_schema': 'dbo',
    'detections_table': 'CROSS_SELL_DETECTIONS',
    'recurring_payments_table': 'CROSS_SELL_RECURRING_PAYMENTS',
    'run_log_table': 'CROSS_SELL_RUN_LOG',
    
    # Product detection thresholds
    'products': {
        'External Mortgage': {
            'min_amount': 100, 'max_amount': 15000, 'max_cv': 0.20,  # Relaxed from 500-10000, 0.15
            'min_tenure': 2, 'expected_channels': ['ACH', 'Bill Pay', 'Check', 'Card']
        },
        'External Auto Loan': {
            'min_amount': 50, 'max_amount': 3000, 'max_cv': 0.15,  # Relaxed from 100-2000, 0.10
            'min_tenure': 2, 'expected_channels': ['ACH', 'Bill Pay', 'Card']
        },
        'External Credit Card': {
            'min_amount': 10, 'max_amount': 10000, 'max_cv': 0.40,  # Relaxed from 25-5000, 0.30
            'min_tenure': 2, 'expected_channels': ['ACH', 'Bill Pay', 'Card']
        },
        'Student Loan': {
            'min_amount': 25, 'max_amount': 3000, 'max_cv': 0.12,  # Relaxed from 50-2000, 0.08
            'min_tenure': 2, 'expected_channels': ['ACH', 'Bill Pay', 'Card']
        },
        'Rent': {
            'min_amount': 200, 'max_amount': 12000, 'max_cv': 0.12,  # Relaxed from 400-8000, 0.08
            'min_tenure': 2, 'expected_channels': ['ACH', 'Check', 'Bill Pay', 'Card']
        },
        'Insurance': {
            'min_amount': 10, 'max_amount': 5000, 'max_cv': 0.20,  # Relaxed from 50-1000, 0.12
            'min_tenure': 2, 'expected_channels': ['ACH', 'Bill Pay', 'Card']
        },
    },
    
    # Merchant taxonomy - Maps YOUR actual CATEGORY1 values to product types
    'taxonomy': {
        # Mortgage-related
        'VA MORTGAGE LOANS': 'External Mortgage',
        'MORTGAGE BANKERS': 'External Mortgage',
        'MORTGAGE BROKERS': 'External Mortgage',
        
        # Auto-related
        'AUTO FINANCING': 'External Auto Loan',
        'AUTOMOBILE ASSOCIATIONS': 'External Auto Loan',
        'CAR WASHES': 'External Auto Loan',
        'USED CAR DEALERS': 'External Auto Loan',
        'TRUCK DEALERS': 'External Auto Loan',
        'TRUCK LEASING SERVICES': 'External Auto Loan',
        
        # Credit Card Payments
        'CREDIT CARD SERVICES': 'External Credit Card',
        'CREDIT REPORTING AGENCIES': 'External Credit Card',
        
        # Student Loans
        'SCHOOLS AND EDUCATIONAL SERVICES': 'Student Loan',
        'COLLEGES AND UNIVERSITIES': 'Student Loan',
        'TUTORING SERVICES': 'Student Loan',
        'TUITION INSURANCE': 'Student Loan',
        
        # Rent
        'VACATION RENTALS': 'Rent',
        'APARTMENT LOCATING SERVICES': 'Rent',
        'REAL ESTATE': 'Rent',
        'PROPERTY MANAGEMENT': 'Rent',
        
        # Insurance (catch-all for various insurance types)
        'UNEMPLOYMENT INSURANCE': 'Insurance',
        'TRAVEL INSURANCE': 'Insurance',
        'TITLE INSURANCE': 'Insurance',
        'HEALTH INSURANCE': 'Insurance',
        'LIFE INSURANCE': 'Insurance',
        'AUTO INSURANCE': 'Insurance',
        'HOMEOWNERS INSURANCE': 'Insurance',
        'RENTERS INSURANCE': 'Insurance',
        'DENTAL INSURANCE': 'Insurance',
        'VISION INSURANCE': 'Insurance',
        'PET INSURANCE': 'Insurance',
        'DISABILITY INSURANCE': 'Insurance',
        'LONG TERM CARE INSURANCE': 'Insurance',
        
        # Utilities (if you want to detect these as recurring)
        'ELECTRIC SERVICES': 'Insurance',  # Using Insurance as catch-all
        'GAS UTILITIES': 'Insurance',
        'WATER UTILITIES': 'Insurance',
        'INTERNET SERVICE PROVIDERS': 'Insurance',
        'CABLE TV': 'Insurance',
        'TELEPHONE SERVICES': 'Insurance',
    },
    
    # Confidence tiers
    'confidence_tiers': {
        'High': {'min': 0.70, 'max': 1.00},
        'Medium': {'min': 0.50, 'max': 0.70},
        'Low': {'min': 0.00, 'max': 0.50},
    }
}


# =============================================================================
# SQL SERVER CONNECTOR
# =============================================================================

class SQLServerConnector:
    """Connects to VSDSESOLDEV03 using Windows Authentication"""
    
    def __init__(self):
        self.server = CONFIG['server']
        self.source_db = CONFIG['source_db']
        self.target_db = CONFIG['target_db']
    
    def _get_conn_string(self, database: str) -> str:
        """Build connection string with Windows Authentication"""
        return (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={self.server};"
            f"DATABASE={database};"
            f"Trusted_Connection=yes;"
        )
    
    def test_connection(self) -> bool:
        """Test connection to both databases"""
        try:
            # Test source
            conn = pyodbc.connect(self._get_conn_string(self.source_db), timeout=5)
            conn.close()
            print(f"✓ Connected to {self.server}/{self.source_db}")
            
            # Test target
            conn = pyodbc.connect(self._get_conn_string(self.target_db), timeout=5)
            conn.close()
            print(f"✓ Connected to {self.server}/{self.target_db}")
            
            return True
        except Exception as e:
            print(f"✗ Connection failed: {e}")
            return False
    
    def load_transactions(
        self,
        start_date: str = '2025-01-01',
        end_date: Optional[str] = None,
        limit: int = 10000
    ) -> pd.DataFrame:
        """
        Load transactions from SEGEDW using your exact query structure.
        
        Returns standardized DataFrame ready for detection engine.
        """
        if end_date is None:
            end_date = datetime.now().strftime('%Y-%m-%d')
        
        # Your exact query from screenshot
        query = f"""
        SELECT TOP {limit}
            [UCIC],
            [UHIC],
            [UPIC],
            [DEPTRANS_DATE],
            [DEPTRANS_POST_DATE],
            [DEPTRANS_PRODUCT_ID],
            [DEPTRANS_CATEGORY_CODE],
            [DEPTRANS_TYPE_CODE],
            [DEPTRANS_STATUS],
            [DEPTRANS_AMOUNT],
            [DEPTRANS_PAYEE],
            [DEPTRANS_MEMO],
            [MERCHANT],
            [CATEGORY1],
            [CATEGORY2],
            [DEPTRANS_CATEGORY_DESC],
            [DEPTRANS_TYPE_DESC],
            [CLEANSED]
        FROM [{self.source_db}].[{CONFIG['source_schema']}].[{CONFIG['source_table']}]
        WHERE [CLEANSED] IS NOT NULL
            AND [DEPTRANS_POST_DATE] > '{start_date}'
            AND [DEPTRANS_POST_DATE] <= '{end_date}'
        ORDER BY [DEPTRANS_POST_DATE] DESC
        """
        
        print(f"\nLoading from {self.source_db}.{CONFIG['source_schema']}.{CONFIG['source_table']}")
        print(f"Date range: {start_date} to {end_date}, limit: {limit:,}")
        
        conn = pyodbc.connect(self._get_conn_string(self.source_db))
        df = pd.read_sql(query, conn)
        conn.close()
        
        print(f"✓ Loaded {len(df):,} rows from SQL Server")
        
        # Transform to engine schema
        return self._transform_schema(df)
    
    def _transform_schema(self, df: pd.DataFrame) -> pd.DataFrame:
        """Transform your schema to engine schema"""
        channel_map = {'POS': 'Card', 'ACH': 'ACH', 'CHECK': 'Check', 'BILL': 'Bill Pay'}
        
        transformed = pd.DataFrame({
            'customer_id': df['UCIC'].astype(str),
            'transaction_date': pd.to_datetime(df['DEPTRANS_POST_DATE'], errors='coerce'),
            'amount': pd.to_numeric(df['DEPTRANS_AMOUNT'], errors='coerce'),
            'channel': df.get('DEPTRANS_TYPE_CODE', 'POS').map(channel_map).fillna('Card'),
            'merchant': df.get('CLEANSED', df.get('MERCHANT', 'UNKNOWN')).fillna('UNKNOWN'),
            'category': df['CATEGORY1'],
        })
        
        # Clean
        transformed = transformed.dropna(subset=['transaction_date', 'amount'])
        transformed = transformed[transformed['amount'] > 0].reset_index(drop=True)
        
        print(f"✓ Transformed: {len(transformed):,} valid transactions, {transformed['customer_id'].nunique():,} customers")
        
        return transformed
    
    def save_detections(self, detections_df: pd.DataFrame) -> int:
        """Save detection results to DATASCIENCE.dbo.CROSS_SELL_DETECTIONS"""
        if detections_df.empty:
            print("⚠ No detections to save")
            return 0
        
        conn = pyodbc.connect(self._get_conn_string(self.target_db))
        
        # Add run metadata
        df = detections_df.copy()
        df.insert(0, 'RUN_TIMESTAMP', datetime.now())
        df.insert(1, 'RUN_ID', datetime.now().strftime('%Y%m%d_%H%M%S'))
        
        # Uppercase columns
        df.columns = [c.upper() for c in df.columns]
        
        # Write to table
        print(f"\nWriting {len(df):,} detections to {self.target_db}.{CONFIG['target_schema']}.{CONFIG['detections_table']}")
        
        df.to_sql(
            name=CONFIG['detections_table'],
            schema=CONFIG['target_schema'],
            con=conn,
            if_exists='append',
            index=False,
            method='multi',
            chunksize=1000
        )
        
        conn.close()
        print(f"✓ Saved successfully")
        return len(df)


# =============================================================================
# PUBLIC API
# =============================================================================

_connector = None

def get_connector() -> SQLServerConnector:
    """Get singleton connector instance"""
    global _connector
    if _connector is None:
        _connector = SQLServerConnector()
    return _connector


def load_transactions(
    start_date: str = '2025-01-01',
    end_date: Optional[str] = None,
    limit: int = 10000
) -> pd.DataFrame:
    """Load transactions from SEGEDW"""
    connector = get_connector()
    return connector.load_transactions(start_date, end_date, limit)


def save_detections(detections_df: pd.DataFrame) -> int:
    """Save detection results to DATASCIENCE"""
    connector = get_connector()
    return connector.save_detections(detections_df)


def test_connection() -> bool:
    """Test SQL Server connection"""
    connector = get_connector()
    return connector.test_connection()
