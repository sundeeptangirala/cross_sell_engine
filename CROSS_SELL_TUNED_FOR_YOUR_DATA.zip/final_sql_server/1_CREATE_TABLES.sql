/*
================================================================================
Cross-Sell Intelligence Engine - DDL Script
================================================================================
Target Server: VSDSESOLDEV03
Target Database: DATASCIENCE
Schema: dbo

INSTRUCTIONS:
1. Open SQL Server Management Studio
2. Connect to VSDSESOLDEV03
3. Select database: DATASCIENCE
4. Execute this entire script

This will create 3 tables:
  - CROSS_SELL_DETECTIONS (main output)
  - CROSS_SELL_RECURRING_PAYMENTS (intermediate patterns)
  - CROSS_SELL_RUN_LOG (execution history)

================================================================================
*/

USE [DATASCIENCE];
GO

PRINT '';
PRINT '========================================================================';
PRINT 'Creating Cross-Sell Intelligence Tables';
PRINT '========================================================================';
PRINT '';

-- =============================================================================
-- TABLE 1: CROSS_SELL_DETECTIONS (Main Output)
-- =============================================================================

PRINT 'Creating table: dbo.CROSS_SELL_DETECTIONS';

IF NOT EXISTS (
    SELECT * FROM sys.tables t
    JOIN sys.schemas s ON t.schema_id = s.schema_id
    WHERE s.name = 'dbo' AND t.name = 'CROSS_SELL_DETECTIONS'
)
BEGIN
    CREATE TABLE [dbo].[CROSS_SELL_DETECTIONS] (
        -- Identity & Run Metadata
        [DETECTION_ID] INT IDENTITY(1,1) NOT NULL,
        [RUN_TIMESTAMP] DATETIME2(7) NOT NULL DEFAULT GETDATE(),
        [RUN_ID] VARCHAR(50) NULL,
        
        -- Customer & Product
        [CUSTOMER_ID] VARCHAR(50) NOT NULL,
        [DETECTED_PRODUCT_TYPE] VARCHAR(100) NOT NULL,
        
        -- Confidence & Scoring
        [CONFIDENCE_TIER] VARCHAR(20) NOT NULL,
        [CONFIDENCE_SCORE] DECIMAL(5,4) NOT NULL,
        
        -- Temporal Attributes
        [FIRST_DETECTED_DATE] VARCHAR(50) NOT NULL,
        [LAST_DETECTED_DATE] VARCHAR(50) NOT NULL,
        [TENURE_MONTHS] DECIMAL(6,2) NOT NULL,
        
        -- Payment Attributes
        [RECURRING_AMOUNT_BAND] VARCHAR(50) NULL,
        [MEAN_AMOUNT] DECIMAL(12,2) NULL,
        [CANONICAL_MERCHANT] VARCHAR(200) NULL,
        [DOMINANT_CHANNEL] VARCHAR(50) NULL,
        
        -- Evidence & Explainability
        [EVIDENCE_TRANSACTION_REFS] VARCHAR(MAX) NULL,
        [EXPLANATION_REASON_CODES] VARCHAR(MAX) NULL,
        
        -- Constraints
        CONSTRAINT [PK_CROSS_SELL_DETECTIONS] PRIMARY KEY CLUSTERED ([DETECTION_ID] ASC),
        CONSTRAINT [CK_CONFIDENCE_TIER] CHECK ([CONFIDENCE_TIER] IN ('High', 'Medium', 'Low')),
        CONSTRAINT [CK_CONFIDENCE_SCORE] CHECK ([CONFIDENCE_SCORE] >= 0 AND [CONFIDENCE_SCORE] <= 1),
        CONSTRAINT [CK_TENURE] CHECK ([TENURE_MONTHS] >= 0)
    );
    
    -- Performance indexes
    CREATE NONCLUSTERED INDEX [IX_CUSTOMER_ID] 
        ON [dbo].[CROSS_SELL_DETECTIONS] ([CUSTOMER_ID])
        INCLUDE ([DETECTED_PRODUCT_TYPE], [CONFIDENCE_TIER], [CONFIDENCE_SCORE]);
    
    CREATE NONCLUSTERED INDEX [IX_RUN_TIMESTAMP] 
        ON [dbo].[CROSS_SELL_DETECTIONS] ([RUN_TIMESTAMP] DESC);
    
    CREATE NONCLUSTERED INDEX [IX_PRODUCT_TYPE] 
        ON [dbo].[CROSS_SELL_DETECTIONS] ([DETECTED_PRODUCT_TYPE])
        INCLUDE ([CONFIDENCE_TIER], [CUSTOMER_ID]);
    
    CREATE NONCLUSTERED INDEX [IX_CONFIDENCE] 
        ON [dbo].[CROSS_SELL_DETECTIONS] ([CONFIDENCE_TIER], [DETECTED_PRODUCT_TYPE])
        INCLUDE ([CUSTOMER_ID], [CONFIDENCE_SCORE]);
    
    CREATE NONCLUSTERED INDEX [IX_RUN_ID]
        ON [dbo].[CROSS_SELL_DETECTIONS] ([RUN_ID]);
    
    PRINT '  ✓ Table created with 5 indexes';
END
ELSE
BEGIN
    PRINT '  ⚠ Table already exists';
END

GO

-- =============================================================================
-- TABLE 2: CROSS_SELL_RECURRING_PAYMENTS (Intermediate Patterns)
-- =============================================================================

PRINT '';
PRINT 'Creating table: dbo.CROSS_SELL_RECURRING_PAYMENTS';

IF NOT EXISTS (
    SELECT * FROM sys.tables t
    JOIN sys.schemas s ON t.schema_id = s.schema_id
    WHERE s.name = 'dbo' AND t.name = 'CROSS_SELL_RECURRING_PAYMENTS'
)
BEGIN
    CREATE TABLE [dbo].[CROSS_SELL_RECURRING_PAYMENTS] (
        -- Identity
        [RPO_ID] INT IDENTITY(1,1) NOT NULL,
        [RUN_TIMESTAMP] DATETIME2(7) NOT NULL DEFAULT GETDATE(),
        
        -- Customer & Merchant
        [CUSTOMER_ID] VARCHAR(50) NOT NULL,
        [MERCHANT] VARCHAR(200) NOT NULL,
        [CATEGORY] VARCHAR(100) NULL,
        
        -- Amount Statistics
        [MEAN_AMOUNT] DECIMAL(12,2) NOT NULL,
        [MEDIAN_AMOUNT] DECIMAL(12,2) NOT NULL,
        [AMOUNT_CV] DECIMAL(6,4) NOT NULL,
        
        -- Pattern Attributes
        [OCCURRENCE_COUNT] INT NOT NULL,
        [TENURE_MONTHS] DECIMAL(6,2) NOT NULL,
        [CADENCE_TYPE] VARCHAR(20) NOT NULL,
        [CADENCE_STRENGTH] DECIMAL(5,4) NOT NULL,
        [DOMINANT_CHANNEL] VARCHAR(50) NULL,
        
        -- Temporal
        [FIRST_DATE] DATE NOT NULL,
        [LAST_DATE] DATE NOT NULL,
        
        -- Evidence
        [TRANSACTION_IDS] VARCHAR(MAX) NULL,
        
        -- Constraints
        CONSTRAINT [PK_RECURRING_PAYMENTS] PRIMARY KEY CLUSTERED ([RPO_ID] ASC),
        CONSTRAINT [CK_CADENCE_TYPE] CHECK ([CADENCE_TYPE] IN ('monthly', 'biweekly', 'weekly', 'irregular'))
    );
    
    -- Indexes
    CREATE NONCLUSTERED INDEX [IX_RPO_CUSTOMER] 
        ON [dbo].[CROSS_SELL_RECURRING_PAYMENTS] ([CUSTOMER_ID], [MERCHANT]);
    
    CREATE NONCLUSTERED INDEX [IX_RPO_TIMESTAMP]
        ON [dbo].[CROSS_SELL_RECURRING_PAYMENTS] ([RUN_TIMESTAMP] DESC);
    
    PRINT '  ✓ Table created with 2 indexes';
END
ELSE
BEGIN
    PRINT '  ⚠ Table already exists';
END

GO

-- =============================================================================
-- TABLE 3: CROSS_SELL_RUN_LOG (Execution History)
-- =============================================================================

PRINT '';
PRINT 'Creating table: dbo.CROSS_SELL_RUN_LOG';

IF NOT EXISTS (
    SELECT * FROM sys.tables t
    JOIN sys.schemas s ON t.schema_id = s.schema_id
    WHERE s.name = 'dbo' AND t.name = 'CROSS_SELL_RUN_LOG'
)
BEGIN
    CREATE TABLE [dbo].[CROSS_SELL_RUN_LOG] (
        -- Primary Key
        [RUN_ID] VARCHAR(50) NOT NULL,
        
        -- Timing
        [RUN_START_TIME] DATETIME2(7) NOT NULL,
        [RUN_END_TIME] DATETIME2(7) NULL,
        [DURATION_SECONDS] INT NULL,
        
        -- Input Parameters
        [START_DATE] DATE NOT NULL,
        [END_DATE] DATE NOT NULL,
        [ROW_LIMIT] INT NULL,
        
        -- Input Metrics
        [TRANSACTION_COUNT] INT NOT NULL,
        [CUSTOMER_COUNT] INT NOT NULL,
        
        -- Output Metrics
        [DETECTIONS_TOTAL] INT NULL,
        [DETECTIONS_HIGH] INT NULL,
        [DETECTIONS_MEDIUM] INT NULL,
        [DETECTIONS_LOW] INT NULL,
        
        -- Execution Details
        [STATUS] VARCHAR(20) NULL,
        [ERROR_MESSAGE] VARCHAR(MAX) NULL,
        [EXECUTED_BY] VARCHAR(100) NULL,
        [HOST_NAME] VARCHAR(100) NULL,
        
        -- Constraints
        CONSTRAINT [PK_RUN_LOG] PRIMARY KEY CLUSTERED ([RUN_ID] ASC),
        CONSTRAINT [CK_STATUS] CHECK ([STATUS] IN ('SUCCESS', 'FAILED', 'PARTIAL'))
    );
    
    -- Indexes
    CREATE NONCLUSTERED INDEX [IX_RUN_START_TIME]
        ON [dbo].[CROSS_SELL_RUN_LOG] ([RUN_START_TIME] DESC);
    
    CREATE NONCLUSTERED INDEX [IX_STATUS]
        ON [dbo].[CROSS_SELL_RUN_LOG] ([STATUS]);
    
    PRINT '  ✓ Table created with 2 indexes';
END
ELSE
BEGIN
    PRINT '  ⚠ Table already exists';
END

GO

-- =============================================================================
-- VALIDATION QUERIES
-- =============================================================================

PRINT '';
PRINT '========================================================================';
PRINT 'Validation';
PRINT '========================================================================';
PRINT '';

-- Check tables exist
SELECT 
    t.name AS TABLE_NAME,
    SUM(CASE WHEN i.type = 1 THEN 1 ELSE 0 END) AS CLUSTERED_INDEX_COUNT,
    SUM(CASE WHEN i.type = 2 THEN 1 ELSE 0 END) AS NONCLUSTERED_INDEX_COUNT
FROM sys.tables t
LEFT JOIN sys.indexes i ON t.object_id = i.object_id
WHERE t.name IN ('CROSS_SELL_DETECTIONS', 'CROSS_SELL_RECURRING_PAYMENTS', 'CROSS_SELL_RUN_LOG')
GROUP BY t.name
ORDER BY t.name;

PRINT '';
PRINT '========================================================================';
PRINT 'Setup Complete';
PRINT '========================================================================';
PRINT '';
PRINT 'Next steps:';
PRINT '  1. Verify tables created above';
PRINT '  2. Open command prompt in your project folder';
PRINT '  3. Run: streamlit run ui.py --server.port 8501';
PRINT '  4. Open browser: http://localhost:8501';
PRINT '';
PRINT '========================================================================';

GO
