# Cross-Sell Intelligence Engine - SQL Server Production Version

**Ready to run on your VSDSESOLDEV03 server**

## Your Configuration

- **Server:** VSDSESOLDEV03
- **Source:** SEGEDW.SEG_E0.SAT_SEG_DEP_TRAN
- **Target:** DATASCIENCE.dbo.*
- **Authentication:** Windows (MYFNB\tangiralas)
- **UI:** http://localhost:8501

## Setup Steps (Do Once)

### Step 1: Create Database Tables

1. Open SQL Server Management Studio
2. Connect to `VSDSESOLDEV03`
3. Open file: `1_CREATE_TABLES.sql`
4. Make sure you're using DATASCIENCE database:
   ```sql
   USE DATASCIENCE;
   GO
   ```
5. Execute the script (F5)
6. Verify you see:
   ```
   ✓ Table created with 5 indexes
   ✓ Table created with 2 indexes  
   ✓ Table created with 2 indexes
   ```

### Step 2: Install Python Dependencies

Open Command Prompt in this folder and run:

```bash
pip install -r requirements.txt
```

This installs:
- pandas
- numpy
- streamlit
- plotly
- pyodbc

### Step 3: Test Connection

```bash
python -c "from data import test_connection; test_connection()"
```

You should see:
```
✓ Connected to VSDSESOLDEV03/SEGEDW
✓ Connected to VSDSESOLDEV03/DATASCIENCE
```

If it fails, verify:
- You're on the corporate network
- Your Windows account has access to both databases
- ODBC Driver 17 for SQL Server is installed

## Running the Application

### Start the UI

```bash
streamlit run ui.py --server.port 8501
```

Your browser will automatically open to: http://localhost:8501

### Using the UI

1. **Set Date Range** (sidebar)
   - Start Date: e.g., 90 days ago
   - End Date: Today
   - Max Rows: 10,000 (adjust as needed)

2. **Load Data** (sidebar)
   - Click "🔄 Load Data"
   - Wait for SQL query to complete
   - You'll see: "✓ Loaded in X.Xs"

3. **View Results** (main area)
   - **Portfolio View:** KPIs, charts, full table
   - **Customer View:** Search by UCIC, see detail
   - **Config:** View thresholds and settings

4. **Save Results** (sidebar)
   - Click "💾 Save to Database"
   - Saves to DATASCIENCE.dbo.CROSS_SELL_DETECTIONS

5. **Download** (portfolio view)
   - Click "📥 Download Filtered Results"
   - Gets CSV of current view

## Files

- `data.py` - SQL Server connector (your exact config)
- `model.py` - Detection engine
- `ui.py` - Streamlit interface
- `1_CREATE_TABLES.sql` - DDL script (run once)
- `requirements.txt` - Python dependencies
- `README.md` - This file

## Query Your Results

After saving detections, query them in SSMS:

```sql
-- Recent detections
SELECT TOP 100 *
FROM DATASCIENCE.dbo.CROSS_SELL_DETECTIONS
ORDER BY RUN_TIMESTAMP DESC;

-- Summary by product
SELECT 
    DETECTED_PRODUCT_TYPE,
    CONFIDENCE_TIER,
    COUNT(*) as COUNT,
    AVG(MEAN_AMOUNT) as AVG_AMOUNT
FROM DATASCIENCE.dbo.CROSS_SELL_DETECTIONS
GROUP BY DETECTED_PRODUCT_TYPE, CONFIDENCE_TIER
ORDER BY DETECTED_PRODUCT_TYPE, CONFIDENCE_TIER;

-- Customers with multiple relationships
SELECT 
    CUSTOMER_ID,
    COUNT(*) as PRODUCT_COUNT,
    STRING_AGG(DETECTED_PRODUCT_TYPE, ', ') as PRODUCTS
FROM DATASCIENCE.dbo.CROSS_SELL_DETECTIONS
WHERE CONFIDENCE_TIER IN ('High', 'Medium')
GROUP BY CUSTOMER_ID
HAVING COUNT(*) > 1
ORDER BY PRODUCT_COUNT DESC;
```

## Products Detected

- External Mortgage ($500-$10K/mo)
- External Auto Loan ($100-$2K/mo)
- External Credit Card ($25-$5K/mo)
- Student Loan ($50-$2K/mo)
- Rent ($400-$8K/mo)
- Insurance ($50-$1K/mo)

## Troubleshooting

**"Connection failed"**
- Check VPN/network access
- Verify database permissions
- Install ODBC Driver 17: https://go.microsoft.com/fwlink/?linkid=2249006

**"Module not found"**
- Run: `pip install -r requirements.txt`

**"Table does not exist"**
- Run `1_CREATE_TABLES.sql` in SSMS first

**Slow loading**
- Reduce "Max Rows" (try 1,000 first)
- Narrow date range
- Check SEGEDW table indexes

**No detections found**
- Check date range has data
- Verify CLEANSED field is populated
- Try longer date range (6+ months)

## Configuration

Edit `data.py` CONFIG dictionary to change:
- Product amount thresholds
- Confidence tier boundaries
- Expected channels per product
- Taxonomy mappings

## Performance

Expected throughput: 5,000-10,000 transactions/sec
- 1,000 rows: ~0.1 seconds
- 10,000 rows: ~1-2 seconds
- 50,000 rows: ~5-10 seconds

## Support

For issues or questions, check:
1. This README
2. Error messages in Streamlit UI
3. SQL Server connection test results
4. SSMS query results
