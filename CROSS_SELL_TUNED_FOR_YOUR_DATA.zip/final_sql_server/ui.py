"""
ui.py
------
Streamlit UI for Cross-Sell Intelligence Engine

Run: streamlit run ui.py --server.port 8501
Access: http://localhost:8501
"""

import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
from data import load_transactions, save_detections, test_connection, CONFIG
from model import detect_cross_sell

# Page config
st.set_page_config(
    page_title="Cross-Sell Intelligence",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main {background-color: #f4f6f9;}
    .stApp {font-family: 'Segoe UI', sans-serif;}
    h1 {color: #1a2332;}
    .metric-card {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        border-left: 4px solid #3498db;
    }
</style>
""", unsafe_allow_html=True)

# =============================================================================
# DATA LOADING
# =============================================================================

@st.cache_data(ttl=3600)
def load_and_detect(start_date, end_date, limit):
    """Load from SQL Server and run detection (cached for 1 hour)"""
    transactions = load_transactions(start_date=start_date, end_date=end_date, limit=limit)
    detections = detect_cross_sell(transactions)
    return transactions, detections

# =============================================================================
# SIDEBAR
# =============================================================================

st.sidebar.title("🔍 Cross-Sell Engine")
st.sidebar.caption(f"Server: {CONFIG['server']}")
st.sidebar.markdown("---")

# Connection test
with st.sidebar.expander("🔌 Connection Status"):
    if st.button("Test Connection"):
        with st.spinner("Testing..."):
            if test_connection():
                st.success("✓ Connected")
            else:
                st.error("✗ Connection failed")

st.sidebar.markdown("---")

# Query parameters
st.sidebar.subheader("Data Source")
st.sidebar.info(f"**Source:** {CONFIG['source_db']}.{CONFIG['source_schema']}.{CONFIG['source_table']}")

col_start, col_end = st.sidebar.columns(2)
with col_start:
    start_date = st.date_input(
        "Start Date",
        value=datetime.now() - timedelta(days=90),
        max_value=datetime.now()
    )
with col_end:
    end_date = st.date_input(
        "End Date",
        value=datetime.now(),
        max_value=datetime.now()
    )

limit = st.sidebar.number_input(
    "Max Rows",
    min_value=100,
    max_value=100000,
    value=10000,
    step=1000,
    help="Maximum number of transactions to load"
)

# Load button
load_clicked = st.sidebar.button("🔄 Load Data", type="primary", use_container_width=True)

# Initialize session state
if 'transactions' not in st.session_state:
    st.session_state.transactions = None
    st.session_state.detections = None
    st.session_state.load_time = None

# Load data
if load_clicked:
    with st.spinner("Loading from SQL Server..."):
        try:
            start_time = datetime.now()
            transactions, detections = load_and_detect(
                start_date.strftime('%Y-%m-%d'),
                end_date.strftime('%Y-%m-%d'),
                limit
            )
            elapsed = (datetime.now() - start_time).total_seconds()
            
            st.session_state.transactions = transactions
            st.session_state.detections = detections
            st.session_state.load_time = elapsed
            
            st.sidebar.success(f"✓ Loaded in {elapsed:.1f}s")
        except Exception as e:
            st.sidebar.error(f"❌ Load failed: {str(e)}")
            st.stop()

# Save button
if st.session_state.detections is not None and not st.session_state.detections.empty:
    st.sidebar.markdown("---")
    if st.sidebar.button("💾 Save to Database", use_container_width=True):
        with st.spinner("Saving to DATASCIENCE..."):
            try:
                count = save_detections(st.session_state.detections)
                st.sidebar.success(f"✓ Saved {count:,} detections")
            except Exception as e:
                st.sidebar.error(f"❌ Save failed: {str(e)}")

# Navigation
st.sidebar.markdown("---")
if st.session_state.detections is not None and not st.session_state.detections.empty:
    page = st.sidebar.radio("View", ["📊 Portfolio", "👤 Customer", "⚙️ Config"])
else:
    page = "📊 Portfolio"

# =============================================================================
# PAGE: PORTFOLIO VIEW
# =============================================================================

if page == "📊 Portfolio":
    st.title("📊 Portfolio View")
    
    detections = st.session_state.detections
    transactions = st.session_state.transactions
    
    if detections is None or detections.empty:
        st.info("👈 Click 'Load Data' in the sidebar to begin")
        
        st.markdown("### System Configuration")
        col1, col2 = st.columns(2)
        with col1:
            st.markdown(f"""
            **Source Database**
            - Server: `{CONFIG['server']}`
            - Database: `{CONFIG['source_db']}`
            - Table: `{CONFIG['source_schema']}.{CONFIG['source_table']}`
            """)
        with col2:
            st.markdown(f"""
            **Target Database**
            - Server: `{CONFIG['server']}`
            - Database: `{CONFIG['target_db']}`
            - Table: `{CONFIG['target_schema']}.{CONFIG['detections_table']}`
            """)
    else:
        # KPIs
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.markdown(f"""
                <div class="metric-card">
                    <h2 style="margin:0; font-size:32px;">{len(detections):,}</h2>
                    <p style="margin:0; color:#7f8c8d;">Total Detections</p>
                </div>
            """, unsafe_allow_html=True)
        
        with col2:
            customers = detections['customer_id'].nunique()
            st.markdown(f"""
                <div class="metric-card" style="border-left-color:#27ae60;">
                    <h2 style="margin:0; font-size:32px;">{customers:,}</h2>
                    <p style="margin:0; color:#7f8c8d;">Customers</p>
                </div>
            """, unsafe_allow_html=True)
        
        with col3:
            high = len(detections[detections['confidence_tier'] == 'High'])
            st.markdown(f"""
                <div class="metric-card" style="border-left-color:#e67e22;">
                    <h2 style="margin:0; font-size:32px;">{high:,}</h2>
                    <p style="margin:0; color:#7f8c8d;">High Confidence</p>
                </div>
            """, unsafe_allow_html=True)
        
        with col4:
            products = detections['detected_product_type'].nunique()
            st.markdown(f"""
                <div class="metric-card" style="border-left-color:#9b59b6;">
                    <h2 style="margin:0; font-size:32px;">{products}</h2>
                    <p style="margin:0; color:#7f8c8d;">Product Types</p>
                </div>
            """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Charts
        col_left, col_right = st.columns(2)
        
        with col_left:
            st.subheader("Product Distribution")
            prod_counts = detections['detected_product_type'].value_counts()
            fig = px.bar(
                x=prod_counts.values,
                y=prod_counts.index,
                orientation='h',
                color=prod_counts.values,
                color_continuous_scale='Blues'
            )
            fig.update_layout(
                showlegend=False,
                height=300,
                xaxis_title="Count",
                yaxis_title="",
                plot_bgcolor='white'
            )
            st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})
        
        with col_right:
            st.subheader("Confidence Breakdown")
            conf_counts = detections.groupby(['detected_product_type', 'confidence_tier']).size().reset_index(name='count')
            fig = px.bar(
                conf_counts,
                x='detected_product_type',
                y='count',
                color='confidence_tier',
                color_discrete_map={'High': '#27ae60', 'Medium': '#f39c12', 'Low': '#e74c3c'}
            )
            fig.update_layout(
                height=300,
                xaxis_title="",
                yaxis_title="Count",
                plot_bgcolor='white',
                xaxis={'tickangle': -45},
                legend_title_text='Confidence'
            )
            st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})
        
        # Table with filters
        st.subheader("All Detections")
        
        col_prod, col_tier, col_search = st.columns([2, 2, 2])
        with col_prod:
            prod_filter = st.multiselect(
                "Filter by Product",
                options=sorted(detections['detected_product_type'].unique()),
                default=[]
            )
        with col_tier:
            tier_filter = st.multiselect(
                "Filter by Confidence",
                options=['High', 'Medium', 'Low'],
                default=[]
            )
        with col_search:
            search = st.text_input("Search Customer ID (UCIC)", "")
        
        # Apply filters
        filtered = detections.copy()
        if prod_filter:
            filtered = filtered[filtered['detected_product_type'].isin(prod_filter)]
        if tier_filter:
            filtered = filtered[filtered['confidence_tier'].isin(tier_filter)]
        if search:
            filtered = filtered[filtered['customer_id'].str.contains(search, case=False, na=False)]
        
        # Display
        display_df = filtered[[
            'customer_id', 'detected_product_type', 'confidence_tier',
            'confidence_score', 'mean_amount', 'canonical_merchant', 'tenure_months'
        ]].copy()
        display_df['mean_amount'] = display_df['mean_amount'].apply(lambda x: f"${x:,.0f}")
        display_df['confidence_score'] = display_df['confidence_score'].apply(lambda x: f"{x:.2f}")
        display_df['tenure_months'] = display_df['tenure_months'].apply(lambda x: f"{x:.1f} mo")
        display_df.columns = ['Customer', 'Product', 'Confidence', 'Score', 'Amount', 'Merchant', 'Tenure']
        
        st.dataframe(display_df, use_container_width=True, height=400)
        
        st.caption(f"Showing {len(filtered):,} of {len(detections):,} detections")
        
        # Download
        csv = filtered.to_csv(index=False)
        st.download_button(
            label="📥 Download Filtered Results (CSV)",
            data=csv,
            file_name=f"cross_sell_detections_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )

# =============================================================================
# PAGE: CUSTOMER VIEW
# =============================================================================

elif page == "👤 Customer":
    st.title("👤 Customer Detail View")
    
    detections = st.session_state.detections
    
    if detections is None or detections.empty:
        st.info("👈 Load data first")
    else:
        # Customer search
        customer_id = st.text_input("Search by UCIC", placeholder="Enter customer ID...", key="cust_search")
        
        if customer_id:
            cust_det = detections[detections['customer_id'].str.contains(customer_id, case=False, na=False)]
            
            if cust_det.empty:
                st.warning(f"No detections found for '{customer_id}'")
            else:
                # Group by customer
                for cust in cust_det['customer_id'].unique():
                    st.markdown(f"### Customer: `{cust}`")
                    cust_rows = cust_det[cust_det['customer_id'] == cust]
                    
                    st.info(f"Found **{len(cust_rows)} external relationship(s)**")
                    
                    # Show each detection
                    for idx, row in cust_rows.iterrows():
                        tier_emoji = {"High": "🟢", "Medium": "🟡", "Low": "🔴"}[row['confidence_tier']]
                        
                        with st.expander(f"{tier_emoji} {row['detected_product_type']} - {row['confidence_tier']} Confidence ({row['confidence_score']:.2f})"):
                            col1, col2 = st.columns(2)
                            
                            with col1:
                                st.metric("Confidence Score", f"{row['confidence_score']:.2f}")
                                st.metric("Mean Amount", f"${row['mean_amount']:,.0f}")
                                st.metric("Amount Band", row['recurring_amount_band'])
                            
                            with col2:
                                st.metric("Tenure", f"{row['tenure_months']:.1f} months")
                                st.write(f"**Merchant:** {row['canonical_merchant']}")
                                st.write(f"**Channel:** {row['dominant_channel']}")
                            
                            st.write(f"**First Detected:** {row['first_detected_date']}")
                            st.write(f"**Last Detected:** {row['last_detected_date']}")
                            
                            # Signal breakdown
                            st.markdown("**Signal Breakdown:**")
                            codes_str = str(row['explanation_reason_codes'])
                            
                            checks = [
                                ("Monthly Cadence", "CADENCE_MONTHLY" in codes_str),
                                ("Amount Stability", "AMOUNT_STABLE" in codes_str or "AMOUNT_VARIABLE" in codes_str),
                                ("Sufficient Tenure", row['tenure_months'] >= 2),
                                ("Taxonomy Match", "TAXONOMY_MATCH" in codes_str),
                                ("Channel Alignment", "CHANNEL_MATCH" in codes_str),
                            ]
                            
                            rows_html = ""
                            for label, passed in checks:
                                if passed:
                                    icon = "✅"
                                    color = "#27ae60"
                                    val_text = "Matched"
                                else:
                                    icon = "⚪"
                                    color = "#95a5a6"
                                    val_text = "—"
                                
                                rows_html += f"""
                                <div style="display:flex; justify-content:space-between; align-items:center;
                                            padding:4px 0; border-bottom:1px solid #eee;">
                                    <div style="font-size:12px; color:#2c3e50;">{icon} {label}</div>
                                    <div style="font-size:11px; color:{color}; font-weight:500;">{val_text}</div>
                                </div>
                                """
                            
                            st.markdown(f"""
                                <div style="background:#f8fafc; border-radius:6px; padding:10px; margin-top:8px;">
                                    {rows_html}
                                    <div style="display:flex; justify-content:space-between; padding-top:6px; margin-top:4px; border-top:2px solid #ddd;">
                                        <div style="font-size:11px; font-weight:600; color:#1a2332;">Composite Score</div>
                                        <div style="font-size:13px; font-weight:700; color:#3498db;">{row['confidence_score']:.2f}</div>
                                    </div>
                                </div>
                            """, unsafe_allow_html=True)
                            
                            st.caption(f"Reason Codes: {row['explanation_reason_codes']}")

# =============================================================================
# PAGE: CONFIGURATION
# =============================================================================

elif page == "⚙️ Config":
    st.title("⚙️ System Configuration")
    
    st.subheader("Database Configuration")
    st.json({
        'Server': CONFIG['server'],
        'Source Database': CONFIG['source_db'],
        'Source Table': f"{CONFIG['source_schema']}.{CONFIG['source_table']}",
        'Target Database': CONFIG['target_db'],
        'Detections Table': f"{CONFIG['target_schema']}.{CONFIG['detections_table']}",
        'Recurring Payments Table': f"{CONFIG['target_schema']}.{CONFIG['recurring_payments_table']}",
        'Run Log Table': f"{CONFIG['target_schema']}.{CONFIG['run_log_table']}",
    })
    
    st.subheader("Product Detection Thresholds")
    
    for product, rules in CONFIG['products'].items():
        with st.expander(f"📋 {product}"):
            st.json(rules)
    
    st.subheader("Merchant Taxonomy")
    st.json(CONFIG['taxonomy'])
    
    st.subheader("Confidence Tiers")
    st.json(CONFIG['confidence_tiers'])
    
    st.info("💡 To modify settings, edit the CONFIG dictionary in data.py")

# =============================================================================
# FOOTER
# =============================================================================

st.sidebar.markdown("---")
st.sidebar.caption("Cross-Sell Intelligence Engine v1.0")
st.sidebar.caption(f"Target: {CONFIG['target_db']}.{CONFIG['target_schema']}")

if st.session_state.load_time:
    st.sidebar.caption(f"Last load: {st.session_state.load_time:.1f}s")
