"""
0_TEST_CONNECTION.py
--------------------
Run this BEFORE starting Streamlit to validate everything works.

Usage: python 0_TEST_CONNECTION.py
"""

import sys

print("="*70)
print("  CROSS-SELL ENGINE - PRE-FLIGHT CHECK")
print("="*70)

# Test 1: Python version
print("\n1. Checking Python version...")
if sys.version_info >= (3, 8):
    print(f"   ✓ Python {sys.version_info.major}.{sys.version_info.minor}")
else:
    print(f"   ✗ Python {sys.version_info.major}.{sys.version_info.minor} (need 3.8+)")
    sys.exit(1)

# Test 2: Dependencies
print("\n2. Checking dependencies...")
missing = []

try:
    import pandas
    print("   ✓ pandas")
except ImportError:
    missing.append("pandas")
    print("   ✗ pandas")

try:
    import numpy
    print("   ✓ numpy")
except ImportError:
    missing.append("numpy")
    print("   ✗ numpy")

try:
    import pyodbc
    print("   ✓ pyodbc")
except ImportError:
    missing.append("pyodbc")
    print("   ✗ pyodbc")

try:
    import streamlit
    print("   ✓ streamlit")
except ImportError:
    missing.append("streamlit")
    print("   ✗ streamlit")

try:
    import plotly
    print("   ✓ plotly")
except ImportError:
    missing.append("plotly")
    print("   ✗ plotly")

if missing:
    print(f"\n   ⚠ Missing: {', '.join(missing)}")
    print(f"   Run: pip install -r requirements.txt")
    sys.exit(1)

# Test 3: File structure
print("\n3. Checking files...")
import os
required = ['data.py', 'model.py', 'ui.py', '1_CREATE_TABLES.sql', 'README.md']
for f in required:
    if os.path.exists(f):
        print(f"   ✓ {f}")
    else:
        print(f"   ✗ {f} (missing)")
        sys.exit(1)

# Test 4: SQL Server connection
print("\n4. Testing SQL Server connection...")
try:
    from data import test_connection
    if test_connection():
        print("   ✓ Database connection successful")
    else:
        print("   ✗ Database connection failed")
        print("\n   Troubleshooting:")
        print("   - Are you on the corporate network?")
        print("   - Do you have access to VSDSESOLDEV03?")
        print("   - Is ODBC Driver 17 installed?")
        sys.exit(1)
except Exception as e:
    print(f"   ✗ Connection test failed: {e}")
    sys.exit(1)

# Test 5: Import model
print("\n5. Testing detection model...")
try:
    from model import detect_cross_sell
    print("   ✓ Model imported successfully")
except Exception as e:
    print(f"   ✗ Model import failed: {e}")
    sys.exit(1)

# Test 6: Check database tables
print("\n6. Checking DATASCIENCE tables...")
try:
    import pyodbc
    conn_str = (
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=VSDSESOLDEV03;"
        "DATABASE=DATASCIENCE;"
        "Trusted_Connection=yes;"
    )
    conn = pyodbc.connect(conn_str, timeout=5)
    cursor = conn.cursor()
    
    tables = ['CROSS_SELL_DETECTIONS', 'CROSS_SELL_RECURRING_PAYMENTS', 'CROSS_SELL_RUN_LOG']
    for table in tables:
        cursor.execute(f"SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='{table}'")
        if cursor.fetchone()[0] == 1:
            print(f"   ✓ {table}")
        else:
            print(f"   ✗ {table} (not found)")
            print(f"\n   Run 1_CREATE_TABLES.sql in SSMS first!")
            conn.close()
            sys.exit(1)
    
    conn.close()
    print("   ✓ All tables exist")
except Exception as e:
    print(f"   ✗ Table check failed: {e}")
    print(f"\n   Did you run 1_CREATE_TABLES.sql in SSMS?")
    sys.exit(1)

# Success
print("\n" + "="*70)
print("  ✅ ALL CHECKS PASSED")
print("="*70)
print("\nReady to run!")
print("\nNext step:")
print("  streamlit run ui.py --server.port 8501")
print("\nThen open: http://localhost:8501")
print("="*70)
